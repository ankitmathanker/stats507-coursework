#!/bin/bash
#SBATCH --job-name=OC25_seq_spc
#SBATCH --output=slurm_%j.out
#SBATCH --error=slurm_%j.err
#SBATCH --partition=GPU-shared
#SBATCH --gres=gpu:v100-32:1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=4
#SBATCH --time=01:00:00
#SBATCH --account=chm250023p

# ── Environment ──────────────────────────────────────────────────────────────
module purge
module load cuda/12.4.0

source ~/miniconda3/etc/profile.d/conda.sh
conda activate /ocean/projects/chm250023p/ankitma/conda_envs/fairchem-core

# ── Hugging Face auth + cache ────────────────────────────────────────────────
export HF_HOME=/ocean/projects/chm250023p/ankitma/.cache/huggingface
export HUGGINGFACE_HUB_CACHE=$HF_HOME
export HUGGINGFACE_HUB_TOKEN="$(cat ~/.tokens/.hf_token)"
export HF_TOKEN="$HUGGINGFACE_HUB_TOKEN"
export FAIRCHEM_CACHE_DIR=/ocean/projects/chm250023p/ankitma/.cache/fairchem

# ── Config ───────────────────────────────────────────────────────────────────
BASE="/ocean/projects/chm250023p/ankitma/synergistic_project/OC25_SPC"
RUNS_LOG="${BASE}/runs_spc.log"

# Create log with header if it doesn't exist yet
if [ ! -f "${RUNS_LOG}" ]; then
    printf "%-30s  %-45s  %-16s  %s\n" \
        "TIMESTAMP" "FOLDER" "STATUS" "NOTES" > "${RUNS_LOG}"
    printf '%.0s-' {1..110} >> "${RUNS_LOG}"; echo >> "${RUNS_LOG}"
fi

# Helper: check if a folder key is already logged as done
is_logged_done() {
    local key="$1"
    grep -qE "[[:space:]]${key}[[:space:]]+(DONE|FAILED|SKIPPED)" \
        "${RUNS_LOG}" 2>/dev/null
}

# Helper: append a line to the log
log_result() {
    local key="$1"
    local status="$2"
    local notes="$3"
    printf "%-30s  %-45s  %-16s  %s\n" \
        "$(date '+%Y-%m-%d %H:%M:%S')" "${key}" "${status}" "${notes}" >> "${RUNS_LOG}"
}

# ── Run sequentially ─────────────────────────────────────────────────────────
echo "=== OC25 Single-Point Sequential GPU Run ==="
echo "Job started: $(date)"
echo "Node: $(hostname)"
nvidia-smi --query-gpu=name,memory.total --format=csv,noheader 2>/dev/null || true
echo "Log file: ${RUNS_LOG}"
echo ""

TOTAL=0
SKIPPED=0
COMPLETED=0
FAILED=0

for src_folder in from_PBE from_RPBE; do
    for subgroup in molecules slab_molecules; do
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "GROUP: ${src_folder} / ${subgroup}"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

        for leaf_dir in "${BASE}/${src_folder}/${subgroup}"/*/; do
            name=$(basename "${leaf_dir}")
            key="${src_folder}/${subgroup}/${name}"

            # Ensure we only process actual directories
            if [ ! -d "${leaf_dir}" ]; then continue; fi
            
            TOTAL=$((TOTAL + 1))

            # ── Skip if already recorded in runs.log ──
            if is_logged_done "${key}"; then
                echo "[SKIP] ${key}  (in runs_spc.log)"
                SKIPPED=$((SKIPPED + 1))
                continue
            fi

            # ── energy.txt exists but not in log (e.g. previous manual run) ──
            if [ -f "${leaf_dir}/energy.txt" ]; then
                echo "[SKIP] ${key}  (energy.txt exists, logging retroactively)"
                log_result "${key}" "DONE" "Pre-existing energy.txt; logged retroactively"
                SKIPPED=$((SKIPPED + 1))
                continue
            fi

            # ── No POSCAR — skip ──
            if [ ! -f "${leaf_dir}/POSCAR" ]; then
                echo "[WARN] ${key}: no POSCAR found, skipping."
                log_result "${key}" "SKIPPED" "No POSCAR found"
                SKIPPED=$((SKIPPED + 1))
                continue
            fi

            echo ""
            echo ">>> Running: ${key}  ($(date '+%H:%M:%S'))"
            cd "${leaf_dir}"

            # Run single point script
            python run_spc.py --device cuda
            EXIT_CODE=$?

            # Extract energy and Fmax from energy.txt if successful
            NOTES=""
            if [ ${EXIT_CODE} -eq 0 ] && [ -f "energy.txt" ]; then
                E_VAL=$(grep "^Energy" energy.txt | awk '{print $3}')
                F_VAL=$(grep "^Fmax" energy.txt | awk '{print $3}')
                NOTES="E=${E_VAL}eV Fmax=${F_VAL}"
                
                echo "<<< Done:    ${key}  ($(date '+%H:%M:%S'))  ✓ success"
                log_result "${key}" "DONE" "${NOTES}"
                COMPLETED=$((COMPLETED + 1))
            else
                echo "<<< FAILED:  ${key}  ($(date '+%H:%M:%S'))  exit=${EXIT_CODE}"
                log_result "${key}" "FAILED" "exit_code=${EXIT_CODE}"
                FAILED=$((FAILED + 1))
            fi

            cd "${BASE}"
        done
    done
done

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "=== Summary ==="
echo "  Total folders : ${TOTAL}"
echo "  Skipped       : ${SKIPPED}  (already done)"
echo "  Run & finished: ${COMPLETED}"
echo "  Failed        : ${FAILED}"
echo "Job finished: $(date)"
echo "Full log: ${RUNS_LOG}"
