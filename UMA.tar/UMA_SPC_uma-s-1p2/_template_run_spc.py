#!/usr/bin/env python3
"""
Single-point energy and force evaluation using UMA-S (uma-s-1p2).

Model:  uma-s-1p2
Task:   oc20  (surface/adsorbate systems)
Method: Single-point (no geometry optimization)

NOTE: UMA models are gated on HuggingFace (facebook/UMA).
      Ensure HF_TOKEN is set in your environment, or run:
          huggingface-cli login
      before the first run (login node is fine).

Outputs:
  energy.txt    - energy [eV], Fmax [eV/Å], and per-atom forces

Usage:
  python run_spc.py [--device cuda|cpu] [--poscar POSCAR]
"""

import argparse
import sys
import time
from pathlib import Path

import ase.io
import numpy as np

from fairchem.core.calculate.ase_calculator import FAIRChemCalculator

# ── Configuration ─────────────────────────────────────────────────────────────
MODEL_NAME = "uma-s-1p2"

# ── CLI ───────────────────────────────────────────────────────────────────────
def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="UMA-S single-point calculation")
    p.add_argument("--device",  default=None,      help="cuda or cpu (default: auto)")
    p.add_argument("--poscar",  default="POSCAR",  help="Input POSCAR file")
    p.add_argument("--output",  default="energy.txt", help="Output file for energy/forces")
    p.add_argument("--task",    default="oc20",
                   choices=["oc20","oc22","oc25","omol","omat","odac","omc"],
                   help="UMA task name (default: oc20)")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    TASK_NAME = args.task
    t0 = time.time()

    # Detect device
    if args.device is None:
        try:
            import torch
            device = "cuda" if torch.cuda.is_available() else "cpu"
        except ImportError:
            device = "cpu"
    else:
        device = args.device

    print(f"[UMA-S] Model  : {MODEL_NAME}")
    print(f"[UMA-S] Task   : {TASK_NAME}")
    print(f"[UMA-S] Device : {device}")
    print(f"[UMA-S] Mode   : single-point")
    print(f"[UMA-S] Input  : {args.poscar}", flush=True)

    # ── Read structure ─────────────────────────────────────────────────────────
    poscar_path = Path(args.poscar)
    if not poscar_path.exists():
        print(f"ERROR: {poscar_path} not found.", file=sys.stderr)
        sys.exit(1)

    atoms = ase.io.read(str(poscar_path), format="vasp")
    print(f"[UMA-S] Atoms  : {len(atoms)} atoms  |  formula: {atoms.get_chemical_formula()}")

    n_fixed = sum(
        1 for c in atoms.constraints
        if hasattr(c, "get_indices")
        for _ in c.get_indices()
    ) if atoms.constraints else 0
    print(f"[UMA-S] Fixed atoms (from Selective Dynamics): {n_fixed}", flush=True)

    # ── Load calculator ────────────────────────────────────────────────────────
    print("[UMA-S] Loading calculator (may download checkpoint)…", flush=True)
    calc = FAIRChemCalculator.from_model_checkpoint(
        MODEL_NAME,
        task_name=TASK_NAME,
        device=device,
    )
    atoms.calc = calc

    # ── Single-point evaluation ────────────────────────────────────────────────
    energy = atoms.get_potential_energy()
    forces = atoms.get_forces()
    fmax   = float(np.abs(forces).max())
    elapsed = time.time() - t0

    print(f"[UMA-S] Energy : {energy:.6f} eV")
    print(f"[UMA-S] Fmax   : {fmax:.4f} eV/Å")
    print(f"[UMA-S] Time   : {elapsed:.1f} s", flush=True)

    # ── Write output ───────────────────────────────────────────────────────────
    out_path = Path(args.output)
    with open(out_path, "w") as fh:
        fh.write(f"Model    : {MODEL_NAME}\n")
        fh.write(f"Task     : {TASK_NAME}\n")
        fh.write(f"POSCAR   : {poscar_path}\n")
        fh.write(f"Formula  : {atoms.get_chemical_formula()}\n")
        fh.write(f"N_atoms  : {len(atoms)}\n")
        fh.write(f"Energy   : {energy:.6f} eV\n")
        fh.write(f"Fmax     : {fmax:.4f} eV/Å\n")
        fh.write(f"Time     : {elapsed:.1f} s\n")
        fh.write("\n# Per-atom forces [eV/Å]  (fx  fy  fz)\n")
        for i, (fx, fy, fz) in enumerate(forces):
            fh.write(f"  atom {i:4d}:  {fx:12.6f}  {fy:12.6f}  {fz:12.6f}\n")

    print(f"[UMA-S] Wrote  : {out_path}", flush=True)


if __name__ == "__main__":
    main()
